import React from 'react';
import "./App.css";
import * as Reactbootstrap from "react-bootstrap";

const DynamicTable=()=>
{
    const players= [
    {DsID:"b973085",name:"Bala",Role:"Admin"},
    {DsID:"b267098",name:"Nishant",Role:"Super Admin"},
    {DsID:"b386908",name:"Aldo",Role:"Super Admin"}
    ]

    const renderPlayer = (player,index) =>
    {
        return( <tr key={index}>  
            <td>{player.name}</td>          
            <td>{player.DsID}</td>           
            <td>{player.Role}</td>
        </tr>


        )
    }
  
    return(
        <div className="App">
             <Reactbootstrap.Table striped hover size='sm' >
                <thead>
                    <tr>                        
                        <th>Name</th>
                        <th>DsID</th>
                        <th>Role</th>
                    </tr>
                </thead>    
                <tbody>
                   {players.map(renderPlayer)}
                </tbody> 
            </Reactbootstrap.Table>   

        </div>
    );
}
export default DynamicTable;