import React from 'react';
import DataTable from 'react-data-table-component';


class DtTableDemo extends React.Component {
  constructor(props)
  {
    super(props);
    this.updateState = this.updateState.bind(this);
    this.state = {selectedRows:''};
  }
  updateState = state => {
    this.setState({ selectedRows: state.selectedRows });
   alert(this.state.selectedRows);
  }
  
    render() {
        const data = [{ Country: "US", Region: 'NA' },
        {Country:"India",Region:'APAC'} ];
        const columns = [
            {
              name: 'Country',
              selector: 'Country',
              sortable: true,
            },
            {
              name: 'Region',
              selector: 'Region',
              sortable: true
             
            },
          ];
          
      return (
        <DataTable
          title="Configuration Management"
          columns={columns}
          data={data}
          onSelectedRowsChange={this.updateState}
          onRowDoubleClicked = {this.callUpdate}
          
                  />
      )
    }
  };
  export default DtTableDemo;