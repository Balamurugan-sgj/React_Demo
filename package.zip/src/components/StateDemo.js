import React from 'react'
import { Component } from 'react';


class StateDemo extends Component
{
    constructor(props)
    {
        super(props);
        this.state = {data:''};
        this.handleChange = this.handleChange.bind(this);
        
    }

       handleChange(e)
       {
            this.setState({data:e.target.value});
            alert(this.state.data);
       }
    

    render()
    {
        return(
               <input type='text' onChange={this.handleChange} /> 

        )
    
    }
}

export default StateDemo;