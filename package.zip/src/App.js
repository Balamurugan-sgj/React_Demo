import React from 'react';
import Tabs from "./components/Tabs"; 
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css'
import {Navbar,Nav,NavDropdown} from 'react-bootstrap';
import DynamicTable from "./DynamicTable";
import DtTable from "./components/ReactDataTableDemo";
import StateDemo from "./components/StateDemo";

function App() {
  return (
    <div>
    <div> 
    <Navbar collapseOnSelect expand="lg" bg="primary-local" variant="dark" >
  <Navbar.Brand href="#home">GTC-PTT tool</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="mr-auto">
      <Nav.Link href="#features">Audit Lookup</Nav.Link>
      <Nav.Link href="#pricing">Activity Log</Nav.Link>
      <NavDropdown title="Countries" id="collasible-nav-dropdown">
        <NavDropdown.Item href="#action/3.1">US</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.2">Mexico</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.3">Argentina</NavDropdown.Item>
        <NavDropdown.Divider />
        <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
      </NavDropdown>
    </Nav>
    <Nav>
      <Nav.Link href="#deets">Super Admin</Nav.Link>
      <Nav.Link eventKey={2} href="#memes">
        Nishant Verma
      </Nav.Link>
    </Nav>
  </Navbar.Collapse>
</Navbar>
    </div>
   
     <Tabs> 
       <div label="Audit"> 
         See ya later, <em>Under construction</em>! 
       </div> 
       <div label="User Management"> 
          <em>Coming soon</em>! 
         
       </div> 
       <div label="Audit Management"> 
          <div>
            <DynamicTable />
          </div>
          <div>
            <DtTable />
          </div>
          <div>
            <StateDemo />
          </div>

       </div> 
     </Tabs> 
     
    </div>
    
  );
}

export default App;